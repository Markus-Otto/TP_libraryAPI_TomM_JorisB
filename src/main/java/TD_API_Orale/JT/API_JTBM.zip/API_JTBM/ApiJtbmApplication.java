package TD_API_Orale.JT.API_JTBM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiJtbmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiJtbmApplication.class, args);
	}

}
