package TD_API_Orale.JT.API_JTBM.entity;

public enum Genre {
    NOVEL,
    ESSAY,
    POETRY,
    OTHER
}
